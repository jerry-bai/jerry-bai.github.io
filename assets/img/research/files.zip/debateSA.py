import pandas as pd

from sklearn.feature_extraction.text import CountVectorizer
from sklearn.ensemble import RandomForestClassifier

if __name__ == '__main__':
    #--read data--#
    train = pd.read_csv("labeledDebateTrainData.csv")

    num_reviews = train["comment"].size

    print("Creating the bag of words...\n")
    #init bag of words tool, analyze words, max vocabulary of 5000 words
    vectorizer = CountVectorizer(analyzer="word", tokenizer=None, preprocessor=None, stop_words=None, max_features=5000)

    #fit_transform, input is a list of str
    # 1. fit model (learn vocab)
    # 2. transform train data into feature vector
    train_data_features = vectorizer.fit_transform(train["comment"])

    #arrs are easy to work with
    train_data_features = train_data_features.toarray()

    #vocab = vectorizer.get_feature_names()

    print "Training the random forest..."

    #init w/ 100 trees
    forest = RandomForestClassifier(n_estimators=100)
    forest = forest.fit(train_data_features, train["sentiment"])

    #--DONE TRAINING--#
    #--     ...     --#
    #--Begin testing--#

    test = pd.read_csv("labeledDebateTestData.csv")
    #print test.shape

    #get bag of words for test set, convert to numpy arr
    test_data_features = vectorizer.transform(test["comment"])
    test_data_features = test_data_features.toarray()

    result = forest.predict(test_data_features)

    #cp results into dataframe
    output = pd.DataFrame(data = {"comment":test["comment"], "sentiment":result})
    output.to_csv( "Bag_of_Words_model_debateorg.csv")