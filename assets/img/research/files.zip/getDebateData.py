import urllib
import re
import pandas as pd

sock = urllib.urlopen("http://www.debate.org/big-issues/")
bigIssuesSrc = sock.read()
sock.close()

bigIssuesSrc = bigIssuesSrc.split("BIG")[1].split("Previous")[0] #only html for recent big issues
debate_topics = re.findall(r'<a class="issue-title" href="(.*)" title=', bigIssuesSrc)
num_of_topics = len(debate_topics)

#get even number of debates
if num_of_topics % 2 != 0:
    debate_topics = debate_topics[0:num_of_topics-1]
    num_of_topics -= 1

#split topics in half for training and testing
train_topics = debate_topics[0:num_of_topics/2]
test_topics = debate_topics[num_of_topics/2:]

'''
Get the train data
'''

print "Getting the training data"

train_urls = list()
for train_topic in train_topics:
    train_urls.append("http://www.debate.org" + train_topic)

train_output_comments = list()
train_output_sentiments = list()
train_output_num_comments = 0
for train_url in train_urls:
    print("...")
    train_sock = urllib.urlopen(train_url)
    train_html_src = train_sock.read()
    train_sock.close()

    train_all_comments = re.findall(r'Comment:<\/strong>(.*)', train_html_src)
    train_num_comments = len(train_all_comments)
    train_output_num_comments += train_num_comments
    for i in xrange(0, train_num_comments):
        train_output_comments.append(train_all_comments[i])
        if i <= train_num_comments/2:
            train_output_sentiments.append(1)
        else:
            train_output_sentiments.append(0)

#remove \r (bugging up our output csv)
j = 0
for train_output_comment in train_output_comments:
    train_output_comments[j] = train_output_comment.strip("\r")
    j += 1

outdict = dict()
outdict.update({"comment":train_output_comments})
outdict.update({"sentiment":train_output_sentiments})

train_output = pd.DataFrame(data=outdict, index=range(train_output_num_comments))
train_output.to_csv("labeledDebateTrainData.csv")

'''
Get the test data
'''

print "Getting the testing data"
test_urls = list()
for test_topic in test_topics:
    test_urls.append("http://www.debate.org" + test_topic)

test_output_comments = list()
#test_output_sentiments = list()
test_output_num_comments = 0
for test_url in test_urls:
    print("...")
    test_sock = urllib.urlopen(test_url)
    test_html_src = test_sock.read()
    test_sock.close()

    test_all_comments = re.findall(r'Comment:<\/strong>(.*)', test_html_src)
    test_num_comments = len(test_all_comments)
    test_output_num_comments += test_num_comments
    for i in xrange(0, test_num_comments):
        test_output_comments.append(test_all_comments[i])
        #if i <= test_num_comments/2:
        #    test_output_sentiments.append(1)
        #else:
        #    test_output_sentiments.append(0)

#remove \r (bugging up our output csv)
k = 0
for test_output_comment in test_output_comments:
    test_output_comments[k] = test_output_comment.strip("\r")
    k += 1

outdict = dict()
outdict.update({"comment":test_output_comments})
#outdict.update({"sentiment":test_output_sentiments})

test_output = pd.DataFrame(data=outdict, index=range(test_output_num_comments))
test_output.to_csv("labeledDebateTestData.csv")

'''
Get gold test data
'''

print "Getting the gold testing data"
test_urls = list()
for test_topic in test_topics:
    test_urls.append("http://www.debate.org" + test_topic)

test_output_comments = list()
test_output_sentiments = list()
test_output_num_comments = 0
for test_url in test_urls:
    print("...")
    test_sock = urllib.urlopen(test_url)
    test_html_src = test_sock.read()
    test_sock.close()

    test_all_comments = re.findall(r'Comment:<\/strong>(.*)', test_html_src)
    test_num_comments = len(test_all_comments)
    test_output_num_comments += test_num_comments
    for i in xrange(0, test_num_comments):
        test_output_comments.append(test_all_comments[i])
        if i <= test_num_comments/2:
            test_output_sentiments.append(1)
        else:
            test_output_sentiments.append(0)

#remove \r (bugging up our output csv)
l = 0
for test_output_comment in test_output_comments:
    test_output_comments[l] = test_output_comment.strip("\r")
    l += 1

outdict = dict()
outdict.update({"comment":test_output_comments})
outdict.update({"sentiment":test_output_sentiments})

test_output = pd.DataFrame(data=outdict, index=range(test_output_num_comments))
test_output.to_csv("labeledDebateTestData_Gold.csv")